'use strict';

const
	item_ctrl = require('../controllers/item'),
	user_ctrl = require('../controllers/user');

module.exports = [

	// {
	// 	url: '/items',
	// 	method: 'get',
	// 	func: [item_ctrl.get_all]
	// },
	// {
	// 	url: '/items',
	// 	method: 'post',
	// 	func: [item_ctrl.create]
	// },
	// {
	// 	url: '/items/:item_id',
	// 	method: 'get',
	// 	func: [item_ctrl.get_by_id]
	// },
	{
		url: '/items/:item_id',
		method: 'put',
		func: [user_ctrl.identify_client, item_ctrl.is_of_user, item_ctrl.update_by_id]
	},
	{
		url: '/items/:item_id',
		method: 'delete',
		func: [user_ctrl.identify_client, item_ctrl.is_of_user, item_ctrl.delete_by_id]
	}

];
