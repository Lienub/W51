'use strict';

const list_ctrl = require('../controllers/list');

module.exports = [

	{
		url: '/lists',
		method: 'get',
		func: list_ctrl.get_all
	},
	{
		url: '/lists',
		method: 'post',
		func: list_ctrl.create
	},
	{
		url: '/lists/:list_id',
		method: 'get',
		func: list_ctrl.get_by_id
	},
	{
		url: '/lists/:list_id',
		method: 'put',
		func: list_ctrl.update_by_id
	},
	{
		url: '/lists/:list_id',
		method: 'delete',
		func: list_ctrl.delete_by_id
	},
	{
		url: '/lists/:list_id/items',
		method: 'get',
		func: list_ctrl.get_items_of_id
	},
	{
		url: '/lists/:list_id/items',
		method: 'post',
		func: list_ctrl.add_item_to_id
	},

];
