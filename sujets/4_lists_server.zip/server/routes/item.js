'use strict';

const item_ctrl = require('../controllers/item');

module.exports = [

	{
		url: '/items/:item_id',
		method: 'put',
		func: item_ctrl.update_by_id
	},
	{
		url: '/items/:item_id',
		method: 'delete',
		func: item_ctrl.delete_by_id
	}

];
